USE ECOMMERCE_ASSIGNMENT;

SELECT * FROM CUSTOMERS;
SELECT * FROM order_items;
SELECT * FROM ORDERS;
SELECT * FROM payments;
SELECT * FROM product_reviews;
SELECT * FROM products;

#1. Retrieve customer names and emails for email marketing
#This helps the marketing team extract basic customer contact details for campaigns.

SELECT NAME AS CUSTOMERS_NAME, EMAIL AS EMAIL FROM CUSTOMERS;


#2. View complete product catalog with all available details
#The product manager may want to review all product listings in one go.]

SELECT * FROM PRODUCTS;

#3. List all unique product categories
#Useful for analyzing the range of departments or for creating filters on the website.

SELECT distinct CATEGORY AS ALL_CATEGORY_LIST FROM PRODUCTS;

#4. Show all products priced above ₹1,000
#This helps identify high-value items for premium promotions or pricing strategy reviews.

SELECT * FROM products 
WHERE price > 1000; 

#5. Display products within a mid-range price bracket (₹2,000 to ₹5,000)
#A merchandising team might need this to create a mid-tier pricing campaign.

SELECT * FROM products 
WHERE price between 2000 AND 5000;

#6. Fetch data for specific customer IDs (e.g., from loyalty program list)
#his is used when customer IDs are pre-selected from another system.

SELECT * FROM customers
where customer_id IN ("1","2","3","4","8");


#7. Identify customers whose names start with the letter ‘A’
#Used for alphabetical segmentation in outreach or app display.

select * FROM customers AS NAME_START_WITH_A
WHERE NAME LIKE "A%";

#8. List electronics products priced under ₹3,000
#Used by merchandising or frontend teams to showcase budget electronics.

SELECT NAME AS ELECTRONIC_PRODUCT_NAME, PRICE FROM products
WHERE category="ELECTRONICS"
AND price<3000;

#9. Display product names and prices in descending order of price
#This helps teams easily view and compare top-priced items.

SELECT NAME AS PRODUCT_NAME, PRICE AS PRODUCT_PRICE FROM products
order by PRODUCT_PRICE DESC;

#10. Display product names and prices, sorted by price and then by name

SELECT NAME AS PRODUCT_NAME, PRICE AS PRODUCT_PRICE FROM products
order by PRODUCT_PRICE, PRODUCT_NAME ;