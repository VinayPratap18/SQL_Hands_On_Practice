USE ECOMMERCE_ASSIGNMENT;

SELECT * FROM CUSTOMERS;
SELECT * FROM order_items;
SELECT * FROM ORDERS;
SELECT * FROM payments;
SELECT * FROM product_reviews;
SELECT * FROM products;

#1. Retrieve order details along with the customer name (INNER JOIN)
#Used for displaying which customer placed each order.

select customers.name,orders.order_id , orders.status,orders.total_amount
from customers
inner join orders
on customers.customer_id= orders.customer_id;

#2. Get list of products that have been sold (INNER JOIN with order_items)
#Used to find which products were actually included in orders.

select products.product_id,products.name 
from products
inner join order_items
on products.product_id = order_items.product_id
group by product_id;

#3. List all orders with their payment method (INNER JOIN)

select orders.order_id,orders.order_date,orders.status, 
payments.method 
from orders
inner join payments
on orders.order_id = payments.order_id;                                
                                    
#4. Get list of customers and their orders (LEFT JOIN)
#Used to find all customers and see who has or hasn’t placed orders.

select customers.customer_id,orders.order_id,customers.name 
from customers
left join orders
on customers.customer_id = orders.customer_id;

#5. List all products along with order item quantity (LEFT JOIN)
#Useful for inventory teams to track what sold and what hasn’t.

select products.product_id,order_items.order_item_id,
products.name,
products.category,products.price, 
order_items.quantity 
from products 
left join order_items
on products.product_id =  order_items.product_id;

#6. List all payments including those with no matching orders (RIGHT JOIN)
#Rare but used when ensuring all payments are mapped correctly.

select orders.order_id,payments.payment_id,
payments.amount_paid,
payments.payment_date 
from orders
right join payments
on orders.order_id = payments.order_id;


#7. Combine data from three tables: customer, order, and payment
#Used for detailed transaction reports                                    
                                    
select c.customer_id,o.order_id,p.payment_id,
c.name as customer_name, c.email, 
o.order_date,o.status,o.total_amount,
p.payment_date,p.method
from customers c
join orders o
on c.customer_id=o.customer_id
join payments p
on p.order_id = o.order_id;
