USE ECOMMERCE_ASSIGNMENT;

SELECT * FROM CUSTOMERS;
SELECT * FROM order_items;
SELECT * FROM ORDERS;
SELECT * FROM payments;
SELECT * FROM product_reviews;
SELECT * FROM products;

#1. List all products priced above the average product price
#Used by pricing analysts to identify premium-priced products.

select name,price from products
where price > (select avg(price) from products);

#2. Find customers who have placed at least one order
#Used to identify active customers for loyalty campaigns.

select *
from customers 
where customer_id
in (select distinct(customer_id) 
from orders where customer_id is not null);

#3. Show orders whose total amount is above the average for that customer
#Used to detect unusually high purchases per customer.

select o.customer_id,o.order_id,o.status,o.total_amount 
from orders o
where o.total_amount>
(select avg(total_amount) from orders
where customer_id=o.customer_id);

#4. Display customers who haven’t placed any orders
#Used for re-engagement campaigns targeting inactive users.

select * from customers 
where customer_id not in
(select customer_id from orders 
where customer_id is not null);

#5. Show products that were never ordered
#Helps with inventory clearance decisions or product deactivation.

select * from products 
where product_id not in 
(select product_id from order_items 
where product_id is not null);

#6. Show highest value order per customer
#Used to identify the largest transaction made by each customer.

select o.customer_id, o.order_id, o.total_amount 
from orders o
where o.total_amount=
(select max(total_amount) from orders 
where customer_id=o.customer_id)
order by o.customer_id asc;

#7. Highest Order Per Customer (Including Names)
#Used to identify the largest transaction made by each customer. Outputs name as well.

select c.customer_id,o.order_id,c.name as customer_name,
o.total_amount as Highest_Value_order
from customers c
join orders o
on c.customer_id=o.customer_id 
where o.total_amount=(select max(total_amount) 
from orders where customer_id=o.customer_id);
