USE ECOMMERCE_ASSIGNMENT;

SELECT * FROM CUSTOMERS;
SELECT * FROM order_items;
SELECT * FROM ORDERS;
SELECT * FROM payments;
SELECT * FROM product_reviews;
SELECT * FROM products;

#1. Retrieve orders where customer information is missing (possibly due to data migration or deletion)
#Used to identify orphaned orders or test data where customer_id is not linked.

SELECT * FROM ORDERS 
LEFT JOIN customers
ON ORDERS.CUSTOMER_ID=CUSTOMERS.customer_id
where CUSTOMERS.customer_id IS NULL;

#2. Display customer names and emails using column aliases for frontend readability
#Useful for feeding into frontend displays or report headings that require user-friendly labels.

SELECT NAME AS CUSTOMER_NAME,EMAIL AS CUSTOMER_EMAIL FROM customers;

#3. Calculate total value per item ordered by multiplying quantity and item price
#This can help generate per-line item bill details or invoice breakdowns.

select order_item_id, sum(quantity*item_price) 
as Total_Value_Order
from order_items
group by order_item_id;


#4. Combine customer name and phone number in a single column
#Used to show brief customer summaries or contact lists.

select concat(NAME," ",PHONE) AS Customers_phone FROM customers;

#5. Extract only the date part from order timestamps for date-wise reporting
#Helps group or filter orders by date without considering time.

select  order_id, customer_id,date(order_date) as Order_date from orders;

#6. List products that do not have any stock left
#This helps the inventory team identify out-of-stock items

select name as product_name from products
where stock_quantity=0;