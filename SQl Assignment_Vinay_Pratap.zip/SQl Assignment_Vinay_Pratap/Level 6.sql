USE ECOMMERCE_ASSIGNMENT;

SELECT * FROM CUSTOMERS;
SELECT * FROM order_items;
SELECT * FROM ORDERS;
SELECT * FROM payments;
SELECT * FROM product_reviews;
SELECT * FROM products;

#1. List all customers who have either placed an order or written a product review
#sed to identify engaged customers from different activity areas.

select  * from customers where customer_id in 
(select customer_id from orders
union
select customer_id from product_reviews 
where customer_id is not null
);

#2. List all customers who have placed an order as well as reviewed a product [intersect not supported]
#Used to identify highly engaged customers for rewards.

select * from customers where customer_id in
(select customer_id from orders)
and 
customer_id in 
(select customer_id from product_reviews 
where customer_id is not null);
