USE ECOMMERCE_ASSIGNMENT;

SELECT * FROM CUSTOMERS;
SELECT * FROM order_items;
SELECT * FROM ORDERS;
SELECT * FROM payments;
SELECT * FROM product_reviews;
SELECT * FROM products;

#1. Count the total number of orders placed
#Used by business managers to track order volume over time.

select count(*) as total_orders_placed from orders;

#2. Calculate the total revenue collected from all orders
#This gives the overall sales value.

select round(sum(amount_paid)) as total_Sales_amount 
from payments;

#3. Calculate the average order value
#Used for understanding customer spending patterns.

select round(avg(total_amount),2) as average_order_value from orders;

#4. Count the number of customers who have placed at least one order
#This identifies active customers.

select count(distinct(customer_id)) as total_customers_atleat_1_order from orders;

#5. Find the number of orders placed by each customer
#Helpful for identifying top or repeat customers.

select customer_id, count(order_id) 
as total_order 
from orders
group by customer_id;

#6. Find total sales amount made by each customer

select customer_id, sum(total_amount) 
as total_value 
from orders
group by customer_id;

#7. List the number of products sold per category
#This helps category managers assess performance by department.

select products.category , 
count(order_items.quantity) as Count_Items 
from products
join order_items
on products.product_id=order_items.product_id
group by products.category
order by Count_Items desc;


#8. Find the average item price per category
#Useful to compare pricing across departments.

select category, round(avg(price),2) as average_item_price from products
group by category;

#9. Show number of orders placed per day
#Used to track daily business activity and demand trends.

select dayname(order_date) as day, 
count(order_id) as total_no_of_order 
from orders
group by dayname(order_date)
order by total_no_of_order desc;

#10. List total payments received per payment method
#Helps the finance team understand preferred transaction modes.

select method as payment_mode, count(payment_id) as total_payment 
from payments
group by payment_mode
order by total_payment desc;
